import { initPanelAnimation } from "./panel";

export const initHomeAnimations = () => {
  initPanelAnimation();
};
